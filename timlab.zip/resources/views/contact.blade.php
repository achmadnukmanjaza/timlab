@extends('layouts.layout')
@section('content')
    <br><br><title>TimLab</title>
    <!-- START FORM SECTION -->
    <section id="test" class="section-padding team-box">		
        <div class="container"> 
            <div class="row">
                <div class="col-md-12">
					<div class="container">
						<div class="row">							
							<div class="col-md-6">
                                <div class="test">	
                                        <br><br><br><h1>How Can We Help You?</h1>
                                        <h2>Pesanan</h2>
                                        <a href="/order"><p>Membuat Pesanan</p></a>
                                        <a href="/history"><p>Perbarui Pesanan</p></a><br>
                                        <h2>Pertanyaan Umum</h2>
                                        <a href="/feed"><p>Komentar</p></a>
                                        <a href="/antenna"><p>Hubungan Media</p></a><br>
                                        <h2>Pelayanan Pelanggan</h2>
                                        <a href="/antenna"><p>Selesaikan Masalah di Pesanan</p></a>
                                        <a href="/antenna"><p>Informasi Teknis tentang Produk</p></a>
                                        </a><br>
								</div>
                            </div>
                            <div class="col-md-6">
                                <div class="test">
                                <div class="test">	
                                        <br><br><br><h1>Informasi Kontak</h1>
                                        <h2>Alamat Kantor </h2>
                                        <p>Surapati Core Ruko, C8 Jl. PH. Hasan Mustopa No. 39, Bandung, 40192, Jawa Barat, Indonesia.</p><br>
                                        <h2>Email  </h2>
                                        <a href=""><p>cs@timlab.co.id</p></a><br>
                                        <h2>Jam Kerja </h2>
                                        <p>Senin - Jumat, 10.00 - 16.00</p><br>
                                        <h2>Narahubung </h2>
                                        <p>Mr. Tedi Nugraha</p>
                                        <p>+62 811 101098 (Whatsapp)</p>
                                        <p>tedi@timlab.co.id</p>
									</div>
								</div>
                            </div>
						</div>
					</div>
                </div>           
            </div>
        </div>
    </section> 
@stop