@extends('layouts.layout')
@section('content')
    <section id="contactt" class="section-padding team-box">		
        <div class="container"> 
            <div class="row">
                <div class="col-md-12">
					<div class="container">
						<div class="row">							
							<div class="col-md-6">
                                <div class="contactt-bg">
                                    <div class="title-contactt">	
                                        <a href="/antenna">										
                                            <img src="assets/img/kontak.png" alt="">
                                            <p><br><a href="contact">Hubungi Kami ></a></p> 
                                        </a> 
									</div>
								</div>
                            </div>
                            <div class="col-md-6">
                                <div class="contactt-bg">
                                    <div class="title-contactt">
                                        <a href="/antenna">										
                                            <img src="assets/img/komen.png" alt="">
                                            <p><br><a href="/feed">Komentar dan Saran ></a></p> 
                                        </a> 
									</div>
                                </div>
							</div>
						</div>
					</div>
                </div>           
            </div>
        </div>
    </section>    
@stop