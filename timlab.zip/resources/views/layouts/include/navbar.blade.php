 <!--  nav  -->
    <nav id="mainNav" class="navbar navbar-default navbar-fixed-top active">
        <div class="container">
                <!-- Brand and toggle get grouped for better mobile display -->
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                </div>
                

                <!-- Collect the nav links, forms, and other content for toggling -->
                <a class="navbar-brand1 navbar-left" href="/timlab">
                    Tim<span>Lab<span>
                </a>
            <div class="collapse navbar-collapse navbar-right" id="bs-example-navbar-collapse-1">
                <div class="search">
                
                    <ul class="nav navbar-nav mx-auto">
						<li>
                            <a class="page-scroll" href="/timlab">Beranda</a>
                        </li>                        
                        <li>
                            <a class="page-scroll" href="/antenna">Sistem Antenna</a>
                        </li>
                        <!-- <li>
                            <a class="page-scroll" href="/radio">Pemancar Radio</a>
                        </li> -->
                        <li>
                            <a class="page-scroll" href="/solusi">Sistem Solusi</a>
                        </li>                        
                        <li>
                            <a class="page-scroll" href="/service">Layanan</a>
                        </li>
                        <li>
                            <a class="page-scroll" href="/topic">Topik Terkini</a>
                        </li>
                        <li>
                            <a class="page-scroll" href="/about">Tentang Kami</a>
                        </li>
                        <!-- @if(auth()->user())     
                        <li>
                            <a class="page-scroll" href="/history">Riwayat</a>
                        </li> 
                        <li>
                            <a class="page-scroll" href="/logout">Logout</a>
                        </li> 
                        @endif
                        @if(!auth()->user()) 
                        <li>
                            <a class="page-scroll" href="/login">Login</a>
                        </li> 
                        @endif -->
                    </ul>
                    <!-- <div class="navbar-brand navbar-right">
                        <form role="form">
                            <input type="text" class="search-form" autocomplete="off" placeholder="Search">
                                <i class="fa fa-search"></i>
                            </input>
                        </form>
                    </div> -->
                </div>
            </div>
                <!-- navbar-collapse  -->
            </div>        
    </nav>