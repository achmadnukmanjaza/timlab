<!DOCTYPE html>
<html lang="zxx">

<head>
  	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1"> 
    
    <title>Creativo- full responsive landing page template</title>
	 <!-- Standard -->
      <link rel="shortcut icon" href="assets/img/ficon.png">
    <!-- Google Fonts -->
        <link href='https://fonts.googleapis.com/css?family=Roboto:400,300,500,700' rel='stylesheet' type='text/css'>
        <link href='https://fonts.googleapis.com/css?family=Quicksand:300,400,700' rel='stylesheet' type='text/css'>
    <!-- Latest Bootstrap min CSS -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css" type="text/css">
    <!-- latest fonts awesome -->
    <link rel="stylesheet" href="assets/font/css/font-awesome.min.css" type="text/css">
    <!-- Style CSS -->
    <link rel="stylesheet" href="assets/css/style.css" type="text/css">    
    <!--  baguetteBox -->
    <link rel="stylesheet" href="assets/css/baguetteBox.css">
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>

<body>  
     <!--  nav  -->
     <?php echo $__env->make('layouts.include.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
     <!--  endnav  -->
     <!-- START HEARDER SECTION -->
     <?php echo $__env->yieldContent('content'); ?>
	 <!-- START FOOTER SECTION -->
     <?php echo $__env->make('layouts.include.Footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
     <!-- Back to top -->    
        <a href="#" class="back-to-top" id="back-to-top"> <i class="fa fa-chevron-up" aria-hidden="true"></i>
</a>
    <!-- jQuery -->
    <script src="assets/js/jquery.js"></script>
    <!-- Bootstrap Core JavaScript -->
    <script src="assets/js/bootstrap.min.js"></script>
       
    <!-- Plugin JavaScript -->
    <script src="assets/js/jquery.easing.min.js"></script>
    <!-- baguetteBox -->
    <script src="assets/js/baguetteBox.js" async></script>
    <script src="assets/js/plugins.js" async></script>    
     <!--  Custom Theme JavaScript  -->
    <script src="assets/js/custom.js"></script> 
    <!--  Custom Theme filterizr  -->
    <script src="assets/js/jquery.filterizr.js"></script>
    <script src="assets/js/controls.js"></script>   
     <!-- Kick off Filterizr -->
    <script type="text/javascript">
        $(function() {
            //Initialize filterizr with default options
            $('.filtr-container').filterizr();
        });
    </script>
</body>
</html>

<?php /**PATH C:\Users\J34\timlab\resources\views/layouts/layout.blade.php ENDPATH**/ ?>