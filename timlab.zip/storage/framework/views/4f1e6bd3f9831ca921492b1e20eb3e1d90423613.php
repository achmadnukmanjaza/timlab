 <!--  nav  -->
    <nav id="mainNav" class="navbar navbar-default navbar-fixed-top">
        <div class="container">
                <!-- Brand and toggle get grouped for better mobile display -->
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                </div>

                <!-- Collect the nav links, forms, and other content for toggling -->

                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                    <ul class="nav navbar-nav justify-content-center">
						<li>
                            <a class="page-scroll" href="/timlab">Home</a>
                        </li>                        
                        <li>
                            <a class="page-scroll" href="#about">Anntena System</a>
                        </li>
                        <li>
                            <a class="page-scroll" href="#team">Radio Transmitter</a>
                        </li>
                        <li>
                            <a class="page-scroll" href="#services">System Solusion</a>
                        </li>                        
                        <li>
                            <a class="page-scroll" href="#gallery">Services</a>
                        </li>
                        <li>
                            <a class="page-scroll" href="#blog">Hot topic</a>
                        </li>
                        <li>
                            <a class="page-scroll" href="#price">About us</a>
                        </li>     
                    </ul>
                </div>
                <!-- navbar-collapse  -->
            </div>        
    </nav><?php /**PATH C:\Users\J34\timlab\resources\views/layouts/include/navbar.blade.php ENDPATH**/ ?>