<footer class="section-padding footer">		
        <div class="container"> 
            <div class="row">
            <div class="col-md-12">                
                <div class="footer-padding">
                    <div class="row">
                    <div class="col-md-12 text-center">
                        <div class="socialfooter">
                                <a href="#" class="fac"><i class="fa fa-facebook"></i></a>
                                <a href="#" class="twi"><i class="fa fa-twitter"></i></a>
                                <a href="#" class="goo"><i class="fa fa-google-plus"></i></a>
                                <a href="#" class="behance"><i class="fa fa-github" aria-hidden="true"></i></a>
                            </div>
                        <div class="row">
                          <div class="col-md-12 copyright">
                            <p>2016 <span>&copy;</span> CREATIVO</p>
                            </div>
                        </div>
                    </div>
                    </div>                  
                </div>
            </div>
           </div>
        </div>
    </footer><?php /**PATH C:\Users\J34\timlab\resources\views/layouts/include/Footer.blade.php ENDPATH**/ ?>