
<?php $__env->startSection('content'); ?>
    <br><br><title>TimLab</title>
    <!-- START TABLE SECTION -->
    <section id="welcome" class="section-padding welcome">		
        <div class="container"> 
            <div class="row">
                <div class="col-md-12">  
                    <div class="row">                
                        <div class="col-md-12">
                            <div class="title-servicess">
                                <br><h1>Riwayat Order</h1>
                                <div class="table-responsive">
                                    <table class="table" border=2>
                                    <thead>
                                        <tr>
                                            <th class="text-center1" >Id Order</th>
                                            <th class="text-center1" >Nama</th>
                                            <th class="text-center1" >Email</th>
                                            <th class="text-center1" >Nomor Telfon</th>
                                            <th class="text-center1" >Barang Order</th>
                                            <th class="text-center1" >Dibuat</th>
                                            <th class="text-center1" >Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td class="text-center1" ><?php echo e($order->id_order); ?></td>
                                            <td class="text-center1" ><?php echo e($order->name); ?></td>
                                            <td class="text-center1" ><?php echo e($order->email); ?></td>
                                            <td class="text-center1" ><?php echo e($order->tlp); ?></td>
                                            <td class="text-center1" ><?php echo e($order->barang_order); ?></td>
                                            <td class="text-center1" ><?php echo e($order->created_at); ?></td>
                                            <td class="text-center1" >
                                                <center><a href="/<?php echo e($order->id_order); ?>">Edit</a></center>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                    </table><br>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\timlab\resources\views/history.blade.php ENDPATH**/ ?>