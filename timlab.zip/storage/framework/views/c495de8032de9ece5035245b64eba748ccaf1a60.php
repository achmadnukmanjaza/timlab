<footer class="section-padding footer">		
        <div class="container"> 
            <div class="row">
            <div class="col-md-12">                
                <div class="footer-padding">
                    <div class="row">
                    <div class="col-md-12 text-center">
                        <!-- <div class="socialfooter">
                                <a href="#" class="fac"><i class="fa fa-facebook"></i></a>
                                <a href="#" class="twi"><i class="fa fa-twitter"></i></a>
                                <a href="#" class="goo"><i class="fa fa-google-plus"></i></a>
                                <a href="#" class="behance"><i class="fa fa-github" aria-hidden="true"></i></a>
                            </div> -->
                        <div class="row">
                          <div class="col-md-12 copyright">
                              <a href="/feed"><ins>Hubungi Kami</a> <span>untuk informasi lebih lanjut</ins></span>
                            <p>2021 <span>&copy;</span> TimLab</p>
                            </div>
                        </div>
                    </div>
                    </div>                  
                </div>
            </div>
           </div>
        </div>
    </footer><?php /**PATH C:\xampp\htdocs\timlab\resources\views/layouts/include/Footer.blade.php ENDPATH**/ ?>