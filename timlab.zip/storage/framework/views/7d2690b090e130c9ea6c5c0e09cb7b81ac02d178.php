
<?php $__env->startSection('content'); ?>
    <br><br><title>TimLab</title>
    <!-- START ALL SECTION -->
    <section id="contact" class="section-padding team-box">		
        <div class="container"> 
            <div class="row">
                <div class="col-md-12">
					<div class="container">
						<div class="row">	
                            <div class="title-services">
                                <h1>Sistem Solusi</h1>
								<table class="table table-hover">
                                <thead>
                                            <tr>
                                                <th class="teks" >No</th>
                                                <th class="teks" >Kami menyediakan solusi berupa sistem yang sifatnya monitoring, seperti:</th>
                                                <th class="teks" ></th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        <?php $__currentLoopData = $solusi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $solusi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td class="teks" ><?php echo e($solusi->id); ?></td>
                                            <td class="teks" ><?php echo e($solusi->solusi); ?></td>
                                            <td class="teks" ><img src="assets/img/<?php echo e($solusi->foto_solusi); ?>" alt=""></td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                </table><br>	
							</div>
						</div>
					</div>
                </div>           
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\timlab\resources\views/solusi.blade.php ENDPATH**/ ?>