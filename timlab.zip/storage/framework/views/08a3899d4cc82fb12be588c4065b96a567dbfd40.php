<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mail</title>
</head>
<body>
    <h1>Update <?php echo e($email); ?></h1>
    <p>Nama : <?php echo e($name); ?></p>
    <p>Email : <?php echo e($email); ?></p>
    <p>Telefon : <?php echo e($tlp); ?></p>
    <p>Barang Order : <?php echo e($barang_order); ?></p>
</body>
</html><?php /**PATH C:\xampp\htdocs\timlab\resources\views/ordermailupdate.blade.php ENDPATH**/ ?>