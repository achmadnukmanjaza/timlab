
<?php $__env->startSection('content'); ?>
<header id="home" class="header">
        <div class="container"> 
        <div class="row">
            <div class="col-sm-12 text-center">
                <div class="header-text">
                    <h1>Creativo Bootstrap Theme</h1>
                    <p>High Quality Theme</p>   
                    <a href="#welcome" class="page-scroll ank">Read more</a>
                </div>
            </div>
        </div>	      
        </div>
    </header>
     <!-- START HOME SECTION -->
    <section id="welcome" class="section-padding welcome">		
        <div class="container"> 
          <div class="row">
            <div class="col-md-12">  
                <div class="row">                
                <div class="col-md-4">
                    <h2><i class="fa fa-laptop" aria-hidden="true"></i> Web Design & <span>Development</span></h2>
                    <p>There Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam.Nam elementum eleifend diam a vulputate.</p>
                </div>
                <div class="col-md-4">
                    <h2><i class="fa fa-rocket" aria-hidden="true"></i> Creativity & <span>Branding</span></h2>
                    <p>There Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam.Nam elementum eleifend diam a vulputate.</p>
                </div>
                <div class="col-md-4">
                    <h2><i class="fa fa-camera" aria-hidden="true"></i> Web Design & <span>Development</span></h2>
                    <p>There Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam.Nam elementum eleifend diam a vulputate.</p>
                </div>
            </div>
           </div>
        </div>
        </div>
    </section>   

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\J34\timlab\resources\views/timlab.blade.php ENDPATH**/ ?>